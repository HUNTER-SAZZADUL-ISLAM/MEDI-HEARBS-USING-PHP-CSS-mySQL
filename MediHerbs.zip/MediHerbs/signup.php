<?php
session_start();

$conn = new mysqli( 'localhost','root','','mediherbs');
if(!$conn){
    echo 'not connect';
}


if ( isset($_POST["submit"]) ){

//require_once('connect.php');
$FirstName=$_POST['FirstName'];
$LastName=$_POST['LastName'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$age=$_POST['age'];
$password=$_POST['password'];


$query1 = "INSERT INTO userinf1(FirstName,
                                LastName,
                                email ,
                                phone,
                                age,
                                passWord)
    VALUES (
        '$FirstName',
        '$LastName',
        '$email',
        '$phone',
        '$age',
        '$password'

    )";

    if( $conn->query($query1) == TRUE){
       echo 'data  inserted';
    }else{
        echo 'data not inserted';
    }

}

?>























<!DOCTYPE html>
<html>
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box}

/* Full-width input fields */

input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
<body>

<form action="" method="POST">
  <div class="container">
    <h1>Sign Up</h1>
    <p>Please fill in this form to create an account.</p>
    <hr>
    <label for="FirstName"><b>FirstName</b></label>
    <input type="text" placeholder="Enter FirstName" name="FirstName" required>

    <label for="LastName"><b>LastName</b></label>
    <input type="text" placeholder="Enter LastName" name="LastName" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>
    
    <label for="phone"><b>PHONE NUMBER</b></label>
    <input type="text" placeholder="Enter PHONE NUMBER" name="phone" required>

    <label for="gender">Choose a gender:</label>

<select id="gender">
  <option value="Male">Male</option>
  <option value="Female">Female</option>
  <option value="Others">Others</option>

</select>
<br>
<br>
<label for="Age"><b>Age</b></label>
    <input type="Age" placeholder="Enter Age" name="age" required>
    <br>
<br>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required>

    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>

    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="mt-1 pb-2">
								<button name="submit" class="btn btn-success">Sign In</button>
							</div>

                            <div class="mt-1 pb-2">
								Alrady have an account? <a href="login1.php" class="text-decoration-none">Login</a>
							</div>
  </div>
</form>

</body>
</html>
