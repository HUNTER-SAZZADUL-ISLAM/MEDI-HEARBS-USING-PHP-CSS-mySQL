CREATE TABLE userinf1 (
    FirstName varchar(255),
    LastName varchar(255),
    email varchar(255),
    age int(20) ,
    phone varchar(255),
    password VARCHAR (255)
);

mediherbs
