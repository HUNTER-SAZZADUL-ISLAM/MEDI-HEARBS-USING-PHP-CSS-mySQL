
<!DOCTYPE html>
<html>
<head>
<title> MediHerb_home </title>
<link rel="stylesheet" type="text/css" href="home.css"> <!-- css file link -->
</head>
<body>
  <header>
    <div class="main">

    <ul> <!-- for navigation bar unorder list  -->
       <li class="active"><a href="#">HOME</a></li>
       <li><a href="#">DISEASE DETECTION</a></li>
       <li><a href="#">APPLICABLE HERB FOR DITECTED DISEASE</a></li>
       <li><a href="#">DELETE ACCOUNT</a></li>
       <li><a href="#">LIVE CHAT</a></li>
       <li><a href="#">FAQ</a></li>
</ul>
     </div>
     <div class="title"> <!-- header -->
       <h1>MEDI-HERBS</h1>
       </div>
<div class="button"> <!--creat button -->
  <a href="http://localhost/mediHerbs/signup.php" class="btn"><b>signup</b></a>

  <a href="http://localhost/mediHerbs/login1.php" class="btn"><b>Login</b></a>
       </div>
</header>
</body>
</html>
