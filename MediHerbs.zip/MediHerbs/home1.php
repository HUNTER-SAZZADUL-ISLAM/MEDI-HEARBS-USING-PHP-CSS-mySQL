
<!DOCTYPE html>
<html>
<head>
<title>MediHerb_home </title>
<link rel="stylesheet" type="text/css" href="home.css"> <!-- css file link -->
</head>
<body>
  <header>
    <div class="main">

    <ul> <!-- for navigation bar unorder list  -->
       <li class="active"><a href="#">HOME</a></li>
       <li><a href="detection.php">DISEASE DETECTION</a></li>
       <li><a href="HerbINF.php">APPLICABLE HERB FOR DITECTED DISEASE</a></li>
       <li><a href="delete.php">DELETE ACCOUNT</a></li>
       <li><a href="mainbot.php">LIVE CHAT</a></li>
       <li><a href="#">FAQ</a></li>
</ul>
     </div>
     <div class="title"> <!-- header -->
       <h1>Welcome to  MEDI-HERBS</h1>
       </div>

</header>
</body>
</html>
